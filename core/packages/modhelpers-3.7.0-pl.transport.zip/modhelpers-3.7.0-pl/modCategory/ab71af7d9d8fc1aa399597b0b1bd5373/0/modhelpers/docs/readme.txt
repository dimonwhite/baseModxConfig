--------------------
modHelpers
--------------------
Author: Sergey Shlokov <sergant210@bk.ru>
--------------------

Library of the helpfull functions for MODX.

Requirement:
PHP >= 5.5.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/sergant210/modHelpers/issues