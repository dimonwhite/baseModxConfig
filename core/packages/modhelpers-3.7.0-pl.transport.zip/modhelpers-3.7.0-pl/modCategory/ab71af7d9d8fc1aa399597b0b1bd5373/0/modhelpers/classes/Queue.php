<?php
namespace modHelpers;

class Queue
{
    public function __construct()
    {

    }

}