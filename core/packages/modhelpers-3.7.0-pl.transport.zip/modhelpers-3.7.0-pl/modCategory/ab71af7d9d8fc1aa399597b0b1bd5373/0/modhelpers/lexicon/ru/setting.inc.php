<?php

$_lang['area_modhelpers_main'] = 'Основные';

$_lang['setting_modhelpers_bot_user_agents'] = 'Юзер агенты ботов';
$_lang['setting_modhelpers_bot_user_agents_desc'] = 'Разделённые запятой юзер-агенты ботов.';
$_lang['setting_modhelpers_print_template'] = 'Шаблон сообщения';
$_lang['setting_modhelpers_print_template_desc'] = 'Шаблон сообщения для функции print_str. Например, &lt;pre&gt;[[+output]]&lt;/pre&gt;';
$_lang['setting_modhelpers_token_ttl'] = 'Время жизни CSRF токена';
$_lang['setting_modhelpers_token_ttl_desc'] = 'Время жизни CSRF токена в минутах. 0 - до конца сессии.';
$_lang['setting_modhelpers_snippets_path'] = 'Путь к сниппетам';
$_lang['setting_modhelpers_snippets_path_desc'] = 'Папка, в которой хранятся файлы сниппетов.';
$_lang['setting_modhelpers_chunks_path'] = 'Путь к чанкам';
$_lang['setting_modhelpers_chunks_path_desc'] = 'Папка, в которой хранятся файлы чанков.';