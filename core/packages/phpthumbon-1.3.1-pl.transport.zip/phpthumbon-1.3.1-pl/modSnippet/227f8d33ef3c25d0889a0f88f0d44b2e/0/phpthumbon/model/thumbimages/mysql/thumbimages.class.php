<?php
require_once(dirname(dirname(__FILE__)) . '/thumbimages.class.php');
class ThumbImages_mysql extends ThumbImages {}